package com.flappu.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import java.util.Random;

public class FlappyBird extends ApplicationAdapter implements InputProcessor{
	SpriteBatch batch;
	OrthographicCamera camera;
	Texture background;
	Texture background1;
	Texture background2;
	Texture background3;
	Texture tilte;
	Texture playbtn;
	Texture bird;
	Texture bottomtube;
	Texture toptube;
	Texture ground;
	Texture img;
	Texture gameover;
	TextureRegion[] animationFrames;
	TextureRegion[][] tmpFrames;
	BitmapFont font;
	Animation animation;
	Music music1;
	Music music2;
	Sound flap;
	Sound collision;
	float timepass=0;
	Random r;
	int width,height,n,bx,by,btx1,btx2,btx3,tap,bth,tth,v1,v2,v3,e,screenw,screenh,gx1,gx2,gx3,s,a,col;
	float x,y,x1,y1;
	@Override
	public void create ()
	{   batch = new SpriteBatch();
		camera=new OrthographicCamera();
		music1=Gdx.audio.newMusic(Gdx.files.internal("music.mp3"));
		music2=Gdx.audio.newMusic(Gdx.files.internal("music1.mp3"));
		flap=Gdx.audio.newSound(Gdx.files.internal("sfx_wing.ogg"));
		collision=Gdx.audio.newSound(Gdx.files.internal("colision.mp3"));
		img = new Texture("birdanimation.png");
		ground = new Texture("ground.png");
		tilte = new Texture("title.png");
		tmpFrames = TextureRegion.split(img,img.getWidth()/3,img.getHeight());
		animationFrames = new TextureRegion[3];
		int index = 0;
		for (int i = 0; i < 1; i++){
			for(int j = 0; j < 3; j++) {
				animationFrames[index++] = tmpFrames[i][j];
			}
		}
		animation = new Animation(1f/3f,animationFrames);
		background = new Texture("bg.png");
		background1 = new Texture("bg1.png");
		background2 = new Texture("bg2.png");
		background3 = new Texture("bg3.png");
		playbtn = new Texture("playbtn.png");
		bird = new Texture("bird.png");
		bottomtube = new Texture("bottomtube.png");
		toptube = new Texture("toptube.png");
		gameover=new Texture("gameover.png");
		font=new BitmapFont(Gdx.files.internal("font.fnt"));
		font.setColor(Color.WHITE);
		font.getData().setScale(1);
		width=400;
		height=800;
		Gdx.input.setInputProcessor(this);
		r=new Random();
		bx=50;
		by=400;
		btx1=300;
		btx2=550;
		btx3=800;
		bth=270;
		tth=320;
		gx1=0;
		gx2=ground.getWidth();
		gx3=2*ground.getWidth();
	}
	@Override
	public void render ()
	{   batch.setProjectionMatrix(camera.combined);
		camera.setToOrtho(false,480,800);
		camera.update();
		Gdx.gl.glClearColor(1, 1, 1, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		if(s<2000)
		{ music2.stop();
			music1.setLooping(true);
			music1.play();
		}
		else if(s>=2000)
		{ music1.stop();
			music2.setLooping(true);
			music2.play();
		}
		batch.begin();
		if(s>=0&&s<1000)
			batch.draw(background, 0, 0, 480,800);
		else if(s>=1000&&s<2000)
			batch.draw(background1, 0, 0, 480,800);
		else if(s>=2000&&s<3000)
			batch.draw(background2, 0, 0, 480,800);
		else if(s>=3000)
			batch.draw(background3, 0, 0, 480,800);
		if(n==0)
		{ batch.draw(playbtn, 480 / 2 - playbtn.getWidth() / 2, 800 / 2);
			batch.draw(bird,220,500,bird.getWidth()+20,bird.getHeight()+20);
			batch.draw(tilte,50, 600);
		}
		if(n==1)
		{   timepass+=Gdx.graphics.getDeltaTime();
			batch.draw((TextureRegion) animation.getKeyFrame(timepass,true),bx,by,bird.getWidth()+20,bird.getHeight()+20);
			batch.draw(bottomtube,btx1,0,bottomtube.getWidth()+25,bth+v1);
			batch.draw(toptube,btx1,800-tth+v1,toptube.getWidth()+25,tth-v1);
			batch.draw(bottomtube,btx2,0,bottomtube.getWidth()+25,bth+v2);
			batch.draw(toptube,btx2,800-tth+v2,toptube.getWidth()+25,tth-v2);
			batch.draw(bottomtube,btx3,0,bottomtube.getWidth()+25,bth+v3);
			batch.draw(toptube,btx3,800-tth+v3,toptube.getWidth()+25,tth-v3);
			batch.draw(ground,gx1,0,ground.getWidth(),ground.getHeight());
			batch.draw(ground,gx2,0,ground.getWidth(),ground.getHeight());
			batch.draw(ground,gx3,0,ground.getWidth(),ground.getHeight());
			font.draw(batch,"Score="+s/10,310,50);
			if(tap>0)
			{   if(e==0) {
				by = by - 3;
				btx1 = btx1 - 4;
				btx2 = btx2 - 4;
				btx3 = btx3 - 4;
				gx1 = gx1 - 4;
				gx2 = gx2 - 4;
				gx3 = gx3 - 4;
				s++;
				if (btx1 < -bottomtube.getWidth() - 100) {
					btx1 = 600;
					v1 = -100 + r.nextInt(350);
				}
				if (btx2 < -bottomtube.getWidth() - 100) {
					btx2 = 600;
					v2 = -100 + r.nextInt(350);
				}
				if (btx3 < -bottomtube.getWidth() - 100) {
					btx3 = 600;
					v3 = -100 + r.nextInt(350);
				}
			}
				if(by<0||by>760)
					e=1;
				if(bx+bird.getWidth()>=btx1&&bx+bird.getWidth()<=btx1+bottomtube.getWidth()&&by+bird.getHeight()>=0&&by+bird.getHeight()<=bth+v1)
					e=1;
				else if(bx+bird.getWidth()>=btx1&&bx+bird.getWidth()<=btx1+toptube.getWidth()&&by+bird.getHeight()>=800-tth+v1&&by+bird.getHeight()<=800)
					e=1;
				else if(bx+bird.getWidth()>=btx2&&bx+bird.getWidth()<=btx2+bottomtube.getWidth()&&by+bird.getHeight()>=0&&by+bird.getHeight()<=bth+v2)
					e=1;
				else if(bx+bird.getWidth()>=btx2&&bx+bird.getWidth()<=btx2+toptube.getWidth()&&by+bird.getHeight()>=800-tth+v2&&by+bird.getHeight()<=800)
					e=1;
				else if(bx+bird.getWidth()>=btx3&&bx+bird.getWidth()<=btx3+bottomtube.getWidth()&&by+bird.getHeight()>=0&&by+bird.getHeight()<=bth+v3)
					e=1;
				else if(bx+bird.getWidth()>=btx3&&bx+bird.getWidth()<=btx3+toptube.getWidth()&&by+bird.getHeight()>=800-tth+v3&&by+bird.getHeight()<=800)
					e=1;
				if(e==1)
				{   batch.draw((TextureRegion) animation.getKeyFrame(timepass,true),bx,by,bird.getWidth()+20,bird.getHeight()+20);
					batch.draw(bottomtube,btx1,0,bottomtube.getWidth()+25,bth+v1);
					batch.draw(toptube,btx1,800-tth+v1,toptube.getWidth()+25,tth-v1);
					batch.draw(bottomtube,btx2,0,bottomtube.getWidth()+25,bth+v2);
					batch.draw(toptube,btx2,800-tth+v2,toptube.getWidth()+25,tth-v2);
					batch.draw(bottomtube,btx3,0,bottomtube.getWidth()+25,bth+v3);
					batch.draw(toptube,btx3,800-tth+v3,toptube.getWidth()+25,tth-v3);
					batch.draw(ground,gx1,0,ground.getWidth(),ground.getHeight());
					batch.draw(ground,gx2,0,ground.getWidth(),ground.getHeight());
					batch.draw(ground,gx3,0,ground.getWidth(),ground.getHeight());
					batch.draw(gameover,240-gameover.getWidth()/2,470,gameover.getWidth(),gameover.getHeight());
					font.draw(batch,"Score="+s/10,180,420);
					batch.draw(playbtn,160,300);
					font.draw(batch,"Tap To Play",160,250);
					if(col==0)
					{ collision.play();
						col = 1;
					}
					if(a==1) {
						bx = 50;
						by = 400;
						btx1 = 300;
						btx2 = 550;
						btx3 = 800;
						bth = 270;
						tth = 320;
						tap = 0;
						e = 0;
						s = 0;
						a=0;
						col=0;
					}
				}
			}
			if(gx1<-ground.getWidth())
				gx1 = 670;
			else if(gx2<-ground.getWidth())
				gx2=670;
			else if(gx3<-ground.getWidth())
				gx3=670;
		}

		if(x>=190&&x<=285&&y>=340&&y<=390)
		{   n = 1;
			tap = 0;
			x=-10;y=-10;
		}

		batch.end();
	}
	@Override
	public void dispose () {
		batch.dispose();
		background.dispose();
		background1.dispose();
		background2.dispose();
		background3.dispose();
		music1.dispose();
		music2.dispose();
		toptube.dispose();
		bird.dispose();
		bottomtube.dispose();
		gameover.dispose();
		ground.dispose();
		playbtn.dispose();
	}

	@Override
	public void resize(int a, int b) {
		screenw=a;
		screenh=b;

	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button)
	{   if(n==0)
	{   x = (screenX*480)/screenw;
		y = (screenY*800)/screenh;

	}
		if(n==1&&e==0)
		{   by = by + 60;
			flap.play();
			tap++;
		}
		if(e==1)
		{ x1 = (screenX*480)/screenw;
			y1 = (screenY*800)/screenh;
			if(x1>=160&&x1<260&&y1>=444&&y1<492)
				a = 1;
		}
		return true;
	}
	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}
	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}
	@Override
	public boolean keyDown(int keycode) {
		return false;
	}
	@Override
	public boolean keyUp(int keycode) {
		return false;
	}
	@Override
	public boolean keyTyped(char character) {
		return false;
	}
	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}
	@Override
	public boolean scrolled(int amount) {
		return false;
	}
}
